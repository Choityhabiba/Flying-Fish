# Flappy-Fish-Game-Android
Android game written in Java that is much like Flappy Bird but with a fish under water where you have green and yellow dots that increase your score and red dots that decrease your health.


### Game Preview


https://user-images.githubusercontent.com/56756748/119802337-c27e3400-bede-11eb-9889-2cc93d98ed9d.mp4

